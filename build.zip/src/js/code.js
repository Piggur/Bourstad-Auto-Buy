document.querySelector("#side-menu > li.nav-header.nav-header-2 > div.dropdown.profile-element > div > h2").innerHTML = "BRUHSTAD"
document.querySelector("head > title").innerHTML = "BRUHSTAD"